from django.apps import AppConfig


class GravelgoAdminAppConfig(AppConfig):
    name = 'gravelgo_admin_app'

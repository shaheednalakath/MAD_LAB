from django.urls import path

from . import views

app_name = 'gravelgo_admin_app'
urlpatterns = [
    path('admin_login',views.admin_login,name="admin_login"),
    path('admin_logout',views.admin_logout,name="admin_logout"),
    path('admin_log',views.admin_log,name="admin_log"),
    path('admin_profile_display',views.admin_profile_display,name="admin_profile_display"),
    path('admin_profile_update',views.admin_profile_update,name="admin_profile_update"),
    path('admin_hotels_details',views.admin_hotels_details,name="admin_hotels_details"),
    path('admin_users_details',views.admin_users_details,name="admin_users_details"),
    path('admin_travelguid_details',views.admin_travelguid_details,name="admin_travelguid_details"),
    path('admin_vehicles_details',views.admin_vehicles_details,name="admin_vehicles_details")


]

from django.contrib import auth
from django.shortcuts import render, redirect
from user_authentication_app.models import new_user_create
from django.contrib.auth.models import User


def admin_login(request):
    if 'username' in request.session:
        return redirect('gravelgo_admin_app:admin_log')
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            request.session['username'] = username
            auth.login(request, user)
            return redirect('gravelgo_admin_app:admin_log')
        else:
            return redirect("gravelgo_admin_app:admin_login")

    return render(request, "admin_templates/admin_login.html")


def admin_logout(request):
    # auth.logout(request)
    if "username" in request.session:
        request.session.flush()
    return redirect('/')


# Create your views here.
def admin_log(request):
    if 'username' in request.session:
        return render(request, "admin_templates/index.html")
    return redirect('gravelgo_admin_app:admin_login')


def admin_profile_display(request):
    username_r = request.session.get('username')
    obj = User.objects.filter(username=username_r)
    return render(request, 'admin_templates/admin_profile_display.html', {'user_data': obj})


def admin_profile_update(request):
    return render(request, "admin_templates/admin_profile_update.html")


def admin_hotels_details(request):
    return render(request, "admin_templates/admin_hotels_details.html")


def admin_users_details(request):
    return render(request, "admin_templates/admin_users_details.html")


def admin_travelguid_details(request):
    return render(request, "admin_templates/admin_travelguid_details.html")


def admin_vehicles_details(request):
    return render(request, "admin_templates/admin_vehicles_details.html")

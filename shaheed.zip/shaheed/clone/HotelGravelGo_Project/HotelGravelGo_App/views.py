from django.contrib import messages
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.models import User


# def demo(request):
#     name="india"
#
#     return render(request,"index.html",{'name':name})
# def add(request):
#     num1=request.GET["n1"]
#     num2=request.GET["n2"]
#     res=int(num1)+int(num2)
#
#     return render(request,"about.html",{"obj":res})
# from .models import gravelgoUser


def index(request):
    return render(request, "index.html")


def about(request):
    return render(request, "about.html")


def service(request):
    return render(request, "service.html")


def packages(request):
    return render(request, "packages.html")


def destination(request):
    return render(request, "destination.html")


def booking(request):
    return render(request, "booking.html")


def tavelguid(request):
    return render(request, "team.html")


# def testimonial(request):
#     return render(request, "testimonial.html"),


def error(request):
    return render(request, "404.html")


def contact(request):
    return render(request, "contact.html")


# def register(request):
#     return render(request, "register.html")
# def register(request):
#     if request.method == 'POST':
#         user_name = request.POST['name']
#         user_email = request.POST['email']
#         user_phone_number = request.POST['phone']
#         user_password = request.POST['password']
#         user_conform_password = request.POST['cpassword']
#         user_gender = request.POST['gender']
#         user_type_login = request.POST['userType']
#         # Your existing registration code here...
#         if user_password == user_conform_password:
#             if User.objects.filter(username=user_name).exists():
#                 messages.info(request, "usertaken")
#                 return redirect('main:register')
#             elif User.objects.filter(email=user_email).exists():
#                 messages.info(request, "email taken")
#             else:
#                 user = User.objects.create_user(username=user_name, email=user_email, password=user_password)
#                 user.save()
#                 user_add = gravelgoUser(name=user_name, email=user_email, phone_number=user_phone_number,
#                                         gender=user_gender, user_type=user_type_login,
#                                         conform_password=user_conform_password, password=user_password)
#                 user_add.save()
#
#                 # Pass 'user_type_login' to the 'authapp:login' view as a URL parameter
#                 request.session['username']=user_name
#                 return redirect('userauth:login')
#         else:
#             messages.info(request, "password error")
#             return redirect('register')
#
#     return render(request, "register.html")

# def register(request):
#     if request.method == 'POST':
#         user_name = request.POST['name']
#         user_email = request.POST['email']
#         user_phone_number = request.POST['phone']
#         user_password = request.POST['password']
#         user_confirm_password = request.POST['cpassword']
#         user_gender = request.POST['gender']
#         user_type_login = request.POST['userType']
#
#         if user_password == user_confirm_password:
#             # Check if the username is already taken
#             if User.objects.filter(username=user_name).exists():
#                 messages.info(request, "Username taken")
#                 return redirect('register')
#             # Check if the email is already taken
#             elif User.objects.filter(email=user_email).exists():
#                 messages.info(request, "Email taken")
#             else:
#                 # Create a new user in the User model
#                 user = User.objects.create_user(username=user_name, email=user_email, password=user_password)
#                 user.save()
#
#                 # Create a user in the gravelgoUser model
#                 user_add = gravelgoUser(
#                     name=user_name,
#                     email=user_email,
#                     phone_number=user_phone_number,
#                     gender=user_gender,
#                     user_type=user_type_login,
#                     conform_password=user_confirm_password,
#                     password=user_password
#                 )
#                 user_add.save()
#         else:
#             messages.info(request, "Password error")
#             return redirect('register')
#
#         # Pass the 'user_type_login' data as a URL parameter to the login page
#         return redirect("userauth:login")
#
#     return render(request, "register.html")

#
# def register(request):
#     if request.method=="POST":
#         user_name=request.POST.get('name')
#         user_email=request.POST.get('email')
#         user_phone_number=request.POST.get('phone')
#         user_password=request.POST.get('password')
#         user_conform_password=request.POST.get('cpassword')
#         user_gender=request.POST.get('gender')
#         user_type_login=request.POST.get('userType')
#         # print("username",user_name,"email",user_email,"phone number",user_phone_number,"userpassword",user_password,"conform password",user_conform_password,"user genter",user_gender,"usertype",user_type_login)
#         my_user=User.objects.create_user(user_name,user_email,user_phone_number,user_password,user_conform_password,user_gender,user_type_login)
#         my_user.save()
#         print("user created")
#     return render(request, "register.html")
#
#
# def login(request):
#     # if request.method=='GET':
#     #     user_name=request.GET.get('name')
#     #     print("username",user_name)
#     return render(request,"login.html")

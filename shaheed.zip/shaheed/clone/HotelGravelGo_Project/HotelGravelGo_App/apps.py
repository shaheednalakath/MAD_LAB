from django.apps import AppConfig


class HotelgravelgoAppConfig(AppConfig):
    name = 'HotelGravelGo_App'

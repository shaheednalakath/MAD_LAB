from django.urls import path
from . import views

app_name = "gravelgo_travel_guid_app"

urlpatterns = [
    path('travelguide_index',views.travelguide_index,name='travelguide_index')

]

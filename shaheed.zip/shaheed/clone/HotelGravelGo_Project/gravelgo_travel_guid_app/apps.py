from django.apps import AppConfig


class GravelgoTravelGuidAppConfig(AppConfig):
    name = 'gravelgo_travel_guid_app'

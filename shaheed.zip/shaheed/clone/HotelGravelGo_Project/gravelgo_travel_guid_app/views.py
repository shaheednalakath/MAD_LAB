from django.shortcuts import render

# Create your views here.
from django.shortcuts import render


# Create your views here.
def travelguide_index(request):
    return render(request, "travelguide_templates/vehicles_index.html")

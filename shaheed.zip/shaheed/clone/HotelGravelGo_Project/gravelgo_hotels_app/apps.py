from django.apps import AppConfig


class GravelgoHotelsAppConfig(AppConfig):
    name = 'gravelgo_hotels_app'

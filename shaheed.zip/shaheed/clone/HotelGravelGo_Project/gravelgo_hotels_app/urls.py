from django.urls import path
from . import views

app_name = "gravelgo_hotels_app"

urlpatterns = [
    path('hotels_logout',views.hotels_logout,name="hotels_logout"),
    path('hotels_index', views.hotels_index, name='hotels_index'),
    path('hotels_admin_profile',views.hotels_admin_profile,name="hotels_admin_profile"),
    path('hotels_profile_update',views.hotels_profile_update,name="hotels_profile_update"),
    path('hotels_reviews',views.hotels_reviews,name="hotels_reviews"),
    path('hotels_add_rooms',views.hotels_add_rooms,name="hotels_add_rooms"),
    path('hotels_edit_rooms',views.hotels_edit_rooms,name="hotels_edit_room"),
    path('hotels_add_activity',views.hotels_add_activity,name="hotels_add_activity"),
    path('hotels_remove_activity',views.hotels_remove_activity,name="hotels_remove_activity"),
    path('hotels_booking',views.hotels_booking,name="hotels_booking")

]

from django.apps import AppConfig


class GravelgoVehiclesAppConfig(AppConfig):
    name = 'gravelgo_vehicles_app'

from django.urls import path
from . import views

app_name = "gravelgo_vehicles_app"

urlpatterns = [
    path('vehicles_index',views.vehicles_index,name='vehicles_index')

]

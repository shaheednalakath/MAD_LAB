from django.urls import path
from . import views

app_name = "gravelgo_users_app"

urlpatterns = [
    path('users_index', views.users_index, name="users_index")

]

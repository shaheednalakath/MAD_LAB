from django.apps import AppConfig


class GravelgoUsersAppConfig(AppConfig):
    name = 'gravelgo_users_app'

from django.contrib import admin
from .models import new_user_create

# Register your models here.
admin.site.register(new_user_create)

from django.apps import AppConfig


class UserAuthenticationAppConfig(AppConfig):
    name = 'user_authentication_app'

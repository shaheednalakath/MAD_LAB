from django.urls import path

from . import views

app_name = 'user_authentication_app'
urlpatterns = [
    path('register',views.register,name="register"),
    path('auth_app_login', views.auth_app_login, name="auth_app_login"),
    path('auth_app_logout', views.auth_app_logout, name="auth_app_logout"),
    path('admin_login',views.admin_login,name="admin_login"),

]

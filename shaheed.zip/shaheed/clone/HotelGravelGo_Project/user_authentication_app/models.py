from django.db import models


# Create your models here.
class new_user_create(models.Model):
    username = models.CharField(max_length=200)
    email = models.EmailField(max_length=500)
    phone_number = models.PositiveIntegerField(null=True, blank=False)
    password = models.PositiveIntegerField(null=True, blank=False)
    conform_password = models.PositiveIntegerField(null=True, blank=False)
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    user_type = models.CharField(max_length=100)


def __str__(self):
    return self.name

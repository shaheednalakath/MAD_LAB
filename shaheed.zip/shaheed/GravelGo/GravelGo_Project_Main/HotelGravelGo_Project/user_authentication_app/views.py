from django.contrib import messages, auth
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
# Create your views here.
from user_authentication_app.models import new_users_reg
from django.contrib.auth import authenticate, login, logout


def register(request):
    if request.method == 'POST':
        user_name = request.POST['username']
        user_email = request.POST['email']
        user_location = request.POST['location']
        user_phone_number = request.POST['contact_no']
        user_password = request.POST['password']
        user_conform_password = request.POST['cpassword']
        user_photo = request.POST['photo']
        user_gender = request.POST['gender']
        user_type_login = request.POST['userType']
        user_address=request.POST['address']
        if user_password == user_conform_password:
            if User.objects.filter(username=user_name).exists():
                messages.info(request, "user alrady taken")
                return redirect('user_authentication_app:register')
            elif User.objects.filter(email=user_email):
                messages.info(request, "email alredy taken")
                return redirect('user_authentication_app:register')
            else:
                user = User.objects.create_user(username=user_name, email=user_email, password=user_password)
                user.save()
                new_users_reg(username=user_name, email=user_email, location=user_location,address=user_address,
                              contact_no=user_phone_number, password=user_password,
                              conform_password=user_conform_password, photo=user_photo, gender=user_gender,
                              user_type=user_type_login).save()

                return redirect('user_authentication_app:auth_app_login')

        else:
            messages.info(request, "password error")
            return redirect('user_authentication_app:register')

    return render(request, "register.html")


# <option value="1">Admin</option>
# <option value="2">Hotels</option>
# <option value="3">Users</option>
# <option value="4">Travel-Guides</option>
# <option value="5">Vehicles</option>

def auth_app_login(request):
    if 'usertype' == 2 in request.session:
        return redirect('gravelgo_hotels_app:hotels_index')
    elif 'usertype' == 3 in request.session:
        return render('gravelgo_users_app:users_index')
    elif 'usertype' == 4 in request.session:
        return redirect('gravelgo_travel_guid_app:travelguide_index')
    elif 'usertype' == 5 in request.session:
        return redirect('gravelgo_vehicles_app:vehicles_index')
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user_idf = request.GET.get('login_id')
        user_obj = new_users_reg.objects.get(username=username, password=password)
        user_id = user_obj.user_id
        user_acc_find = new_users_reg.objects.get(username=username, password=password, user_id=user_id)
        user_type = user_acc_find.user_type
        user = auth.authenticate(request, username=username, password=password)
        # user_check = new_users_reg.objects.filter(username=username, password=password,user_id=user_idf)
        # user_details = new_users_reg.objects.get(username=username, password=password,user_id=user_idf)
        # user_id = user_details.id
        # user_name = user_details.username
        # user_type = user_details.user_type
        if user_acc_find and user:
            if user_type == '1':
                request.session['usertype'] = user_type
                request.session['username'] = username
                auth.login(request, user)
                return redirect('gravelgo_admin_app:admin_log')
            elif user_type == '2':
                request.session['usertype'] = user_type
                request.session['username'] = username
                auth.login(request, user)
                return redirect('gravelgo_hotels_app:hotels_index')
            elif user_type == '3':
                request.session['usertype'] = user_type
                request.session['username'] = username
                auth.login(request, user)
                return redirect('gravelgo_users_app:users_index')
            elif user_type == '4':
                request.session['usertype'] = user_type
                request.session['username'] = username
                auth.login(request, user)
                return redirect('gravelgo_travel_guid_app:travelguide_index')
            elif user_type == '5':
                request.session['usertype'] = user_type
                request.session['username'] = username
                auth.login(request, user)
                return redirect('gravelgo_vehicles_app:vehicles_index')

        else:
            messages.info(request, "user notfound")
            # request.session['user_id'] = user_id
            # request.session['user_name'] = user_name
            # return redirect('/')
    return render(request, "login.html")


def auth_app_logout(request):
    auth.logout(request)
    # if "username" in request.session:
    #     request.session.flush()
    return redirect('/')


#         if user_password == user_conform_password:
#             if User.objects.filter(username=user_name).exists():
#                 messages.info(request, "usertaken")
#                 return redirect('main:register')
#             elif User.objects.filter(email=user_email).exists():
#                 messages.info(request, "email taken")
#             else:
#                 user = User.objects.create_user(username=user_name, email=user_email, password=user_password)
#                 user.save()
#                 user_add = gravelgoUser(name=user_name, email=user_email, phone_number=user_phone_number,
#                                         gender=user_gender, user_type=user_type_login,
#                                         conform_password=user_conform_password, password=user_password)
#                 user_add.save()
#
#                 # Pass 'user_type_login' to the 'authapp:login' view as a URL parameter
#                 request.session['username']=user_name
#                 return redirect('userauth:login')
#         else:
#             messages.info(request, "password error")
#             return redirect('register')
#
#     return render(request, "register.html")
def admin_login(request):
    return render(request, 'admin_templates/admin_login.html')

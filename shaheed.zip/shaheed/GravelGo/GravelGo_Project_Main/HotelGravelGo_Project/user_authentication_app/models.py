from django.db import models


# Create your models here.
class new_user_create(models.Model):
    username = models.CharField(max_length=200)
    email = models.EmailField(max_length=500)
    phone_number = models.PositiveIntegerField(null=True, blank=False)
    password = models.PositiveIntegerField(null=True, blank=False)
    conform_password = models.PositiveIntegerField(null=True, blank=False)
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES)
    user_type = models.CharField(max_length=100)


class new_users_reg(models.Model):
    user_id = models.AutoField(primary_key=True)
    username = models.TextField(max_length=200, blank=False)
    contact_no = models.TextField(blank=False)
    email = models.EmailField(blank=False)
    location = models.TextField(blank=False)
    password = models.TextField(blank=False)
    conform_password = models.TextField(blank=False)
    status = models.TextField(blank=True)
    photo = models.ImageField(upload_to="user_images/",default='non.jpg',blank=False)
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    gender = models.TextField(choices=GENDER_CHOICES)
    user_type = models.TextField(max_length=100, blank=False)
    address = models.TextField(max_length=200)


def __str__(self):
    return self.name

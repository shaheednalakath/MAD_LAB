from django.contrib import admin

# Register your models here.
from . models import new_users_reg

admin.site.register(new_users_reg)
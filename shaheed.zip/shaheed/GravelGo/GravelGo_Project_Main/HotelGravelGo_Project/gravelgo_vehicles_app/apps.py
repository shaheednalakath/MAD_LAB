from django.apps import AppConfig


class GravelgoVehiclesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gravelgo_vehicles_app'

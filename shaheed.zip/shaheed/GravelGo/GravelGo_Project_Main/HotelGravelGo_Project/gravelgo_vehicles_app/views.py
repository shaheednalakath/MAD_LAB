from django.shortcuts import render, redirect

# Create your views here.
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render


# Create your views here.

def vehicles_index(request):
    if 'username' in request.session:
        return render(request, "vehicles_templates/vehicles_index.html")
    else:
        return redirect('user_authentication_app:auth_app_login')


def vehicles_logout(request):
    if 'username' in request.session:
        request.session.flush()
    return redirect('user_authentication_app:auth_app_login')


def vehicles_profile(request):
    if 'username' in request.session:
        return render(request, "vehicles_templates/vehicles_profile.html")
    else:
        return redirect('user_authentication_app:auth_app_login')


def vehicles_profile_update(request):
    if 'username' in request.session:
        return render(request, "vehicles_templates/vehicles_profile_update.html")
    else:
        return redirect('user_authentication_app:auth_app_login')


def vehicles_remove_activity(request):
    if 'username' in request.session:
        return render(request, "vehicles_templates/vehicles_remove_activicty.html")
    else:
        return redirect('user_authentication_app:auth_app_login')


def vehicles_add_activity(request):
    if 'username' in request.session:
        return render(request, "vehicles_templates/vehicles_add_activicty.html")
    else:
        return redirect('user_authentication_app:auth_app_login')


def vehicles_reviews(request):
    if 'username' in request.session:
        return render(request, "vehicles_templates/vehicles_reviews.html")
    else:
        return redirect('user_authentication_app:auth_app_login')


def vehicles_booking(request):
    if 'username' in request.session:
        return render(request, "vehicles_templates/vehicles_booking.html")
    else:
        return redirect('user_authentication_app:auth_app_login')

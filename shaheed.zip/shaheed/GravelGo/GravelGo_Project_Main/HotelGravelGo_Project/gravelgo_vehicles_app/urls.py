from django.urls import path
from . import views

app_name = "gravelgo_vehicles_app"

urlpatterns = [
    path('vehicles_logout',views.vehicles_logout,name="vehicles_logout"),
    path('vehicles_index',views.vehicles_index,name='vehicles_index'),
    path('vehicles_profile',views.vehicles_profile,name="vehicles_profile"),
    path('vehicles_profile_update',views.vehicles_profile_update,name="vehicles_profile_update"),
    path('vehicles_add_activity',views.vehicles_add_activity, name="vehicles_add_activity"),
    path('vehicles_remove_activity',views.vehicles_remove_activity,name="vehicles_remove_activity"),
    path('vehicles_reviews',views.vehicles_reviews,name="vehicles_reviews"),
    path('vehicles_booking',views.vehicles_booking,name="vehicles_booking")


]

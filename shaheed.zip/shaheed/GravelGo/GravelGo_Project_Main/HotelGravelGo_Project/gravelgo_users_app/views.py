from django.shortcuts import render, redirect

# Create your views here.
from django.shortcuts import render


# Create your views here.
def users_logout(request):
    if 'username' in request.session:
        request.session.flush()
    return redirect('user_authentication_app:auth_app_login')


def users_index(request):
    if 'username' in request.session:
        return render(request, "users_templates/index.html")
    else:
        return redirect('user_authentication_app:auth_app_login')


def users_profile(request):
    if 'username' in request.session:
        return render(request, "users_templates/users_profile.html")
    else:
        return redirect("user_authentication_app:auth_app_login")


def users_profile_update(request):
    if 'username' in request.session:
        return render(request, 'users_templates/user_profile_update.html')
    else:
        return redirect('user_authentication_app:auth_app_login')


def users_hotels(request):
    if 'username' in request.session:
        return render(request, 'users_templates/users_hotels.html')
    else:
        return redirect('user_authentication_app:auth_app_login')


def users_booking(request):
    if 'username' in request.session:
        return render(request, "users_templates/users_booking.html")
    else:
        return redirect("user_authentication_app:auth_app_login")


def users_Trguide(request):
    if 'username' in request.session:
        return render(request, "users_templates/users_Trguide.html")
    else:
        return redirect("user_authentication_app:auth_app_login")


def users_Trbooking(request):
    if 'username' in request.session:
        return render(request, "users_templates/users_Trbooking.html")
    else:
        return redirect("user_authentication_app:auth_app_login")


def users_vehicles(request):
    if "username" in request.session:
        return render(request, "users_templates/users_vehicles.html")
    else:
        return redirect("user_authentication_app:auth_app_login")


def users_vehicles_booking(request):
    if "username" in request.session:
        return render(request, "users_templates/users_vehicles_booking.html")
    else:
        return redirect("user_authentication_app:auth_app_login")


def users_services(request):
    if "username" in request.session:
        return render(request, "users_templates/users_services.html")
    else:
        return redirect("user_authentication_app:auth_app_login")


def users_packages(request):
    if "username" in request.session:
        return render(request, "users_templates/users_packages.html")
    else:
        return redirect("user_authentication_app:auth_app_login")

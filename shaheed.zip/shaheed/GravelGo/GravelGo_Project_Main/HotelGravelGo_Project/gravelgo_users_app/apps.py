from django.apps import AppConfig


class GravelgoUsersAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gravelgo_users_app'

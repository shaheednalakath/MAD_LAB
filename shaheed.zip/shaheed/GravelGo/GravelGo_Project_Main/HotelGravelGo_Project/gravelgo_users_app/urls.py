from django.urls import path
from . import views

app_name = "gravelgo_users_app"

urlpatterns = [
    path('users_logout', views.users_logout, name="users_logout"),
    path('users_index', views.users_index, name="users_index"),
    path('users_profile', views.users_profile, name="users_profile"),
    path('users_profile_update', views.users_profile_update, name="users_profile_update"),
    path('users_hotels', views.users_hotels, name="users_hotels"),
    path('users_booking', views.users_booking, name="users_booking"),
    path('users_Trguide', views.users_Trguide, name="users_Trguide"),
    path('users_Trbooking', views.users_Trbooking, name="users_Trbooking"),
    path('users_vehicles', views.users_vehicles, name="users_vehicles"),
    path('users_vehicles_booking', views.users_vehicles_booking, name="users_vehicles_booking"),
    path('users_services',views.users_services,name="users_services"),
    path('users_packages',views.users_packages,name="users_packages")

]

from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from user_authentication_app.models import new_user_create
from django.contrib.auth.models import User


# Create your views here.
def hotels_logout(request):
    if 'username' in request.session:
        request.session.flush()
    return redirect('/')


def hotels_index(request):
    if 'username' in request.session:
        return render(request, "hotels_templates/hotel_index.html")
    else:
        return redirect("user_authentication_app:auth_app_login")


def hotels_admin_profile(request):
    return render(request, 'hotels_templates/hotels_admin_profile.html')


def hotels_profile_update(request):
    return render(request, "hotels_templates/hotels_profile_update.html")


def hotels_reviews(request):
    return render(request, "hotels_templates/hotels_reviews.html")


def hotels_add_rooms(request):
    return render(request, "hotels_templates/hotels_add_rooms.html")


def hotels_edit_rooms(request):
    return render(request, "hotels_templates/hotels_edit_rooms.html")


def hotels_add_activity(request):
    return render(request, 'hotels_templates/hotels_add_activity.html')


def hotels_remove_activity(request):
    return render(request, "hotels_templates/hotels_remove_activity.html")


def hotels_booking(request):
    return render(request, "hotels_templates/hotels_booking.html")

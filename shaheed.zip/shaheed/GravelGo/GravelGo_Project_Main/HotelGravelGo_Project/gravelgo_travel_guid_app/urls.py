from django.urls import path
from . import views

app_name = "gravelgo_travel_guid_app"

urlpatterns = [
    path('travelguide_logout', views.travelguide_logout, name="travelguide_logout"),
    path('travelguide_index', views.travelguide_index, name='travelguide_index'),
    path('travelguide_profile', views.travelguide_profile, name="travelguide_profile"),
    path('travelguide_profile_update', views.travelguide_profile_update, name="travelguide_profile_update"),
    path('travelguide_add_activity', views.travelguide_add_activity, name="travelguide_add_activity"),
    path('travelguide_remove_activity', views.travelguide_remove_activity, name="travelguide_remove_activity"),
    path('travelguide_reviews', views.travelguide_reviews, name="travelguide_reviews"),
    path('travelguide_booking', views.travelguide_booking, name="travelguide_booking"),

]

from django.apps import AppConfig


class GravelgoTravelGuidAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gravelgo_travel_guid_app'

from django.shortcuts import render, redirect

# Create your views here.
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render


# Create your views here.
def travelguide_logout(request):
    if 'username' in request.session:
        request.session.flush()
    return redirect('/')


def travelguide_index(request):
    if 'username' in request.session:
        return render(request, "travelguide_templates/travelguide_index.html")
    else:
        return redirect('user_authentication_app:auth_app_login')


def travelguide_profile(request):
    return render(request, "travelguide_templates/travelguide_profile.html")


def travelguide_profile_update(request):
    return render(request, "travelguide_templates/travelguide_profile_update.html")


def travelguide_add_activity(request):
    return render(request, "travelguide_templates/travelguide_add_activicty.html")


def travelguide_remove_activity(request):
    return render(request, "travelguide_templates/travelguide_remove_activicty.html")


def travelguide_reviews(request):
    return render(request, "travelguide_templates/travelguide_reviews.html")


def travelguide_booking(request):
    return render(request, "travelguide_templates/travelguide_booking.html")

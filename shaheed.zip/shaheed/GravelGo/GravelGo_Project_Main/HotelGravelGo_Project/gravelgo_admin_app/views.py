from django.shortcuts import render

# Create your views here.
from django.contrib import auth
from django.shortcuts import render, redirect
from user_authentication_app.models import new_users_reg
from django.contrib.auth.models import User


def admin_login(request):
    if 'username' in request.session:
        return redirect('gravelgo_admin_app:admin_log')
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            request.session['username'] = username
            auth.login(request, user)
            return redirect('gravelgo_admin_app:admin_log')
        else:
            return redirect("gravelgo_admin_app:admin_login")

    return render(request, "admin_templates/admin_login.html")


def admin_logout(request):
    # auth.logout(request)
    if "username" in request.session:
        request.session.flush()
    return redirect('/')


# Create your views here.
def admin_log(request):
    if 'username' in request.session:
        return render(request, "admin_templates/index.html")
    return redirect('gravelgo_admin_app:admin_login')


def admin_profile_display(request):
    if "username" in request.session:
        username_r = request.session.get('username')
        obj = new_users_reg.objects.filter(username=username_r)
        # print("......................................................username_r.................................."+username_r)
        return render(request, 'admin_templates/admin_profile_display.html', {'user_data': obj})
    else:
        return redirect("user_authentication_app:auth_app_login")


def admin_profile_update(request):
    if "username" in request.session:
        username_r = request.session.get('username')
        obj = new_users_reg.objects.filter(username=username_r)
        if request.method == "POST":
            username = request.POST['username']
            email = request.POST['email']
            mobile_no = request.POST['mobile_no']
            location = request.POST['location']
            address = request.POST['address']
            photo = request.POST['photo']
        return render(request, "admin_templates/admin_profile_update.html", {"user_data": obj})
    else:
        return redirect("user_authentication_app:auth_app_login")


def admin_hotels_details(request):
    return render(request, "admin_templates/admin_hotels_details.html")


def admin_users_details(request):
    return render(request, "admin_templates/admin_users_details.html")


def admin_travelguid_details(request):
    return render(request, "admin_templates/admin_travelguid_details.html")


def admin_vehicles_details(request):
    return render(request, "admin_templates/admin_vehicles_details.html")

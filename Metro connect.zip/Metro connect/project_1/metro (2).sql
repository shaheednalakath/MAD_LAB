-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2023 at 05:05 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `metro`
--

-- --------------------------------------------------------

--
-- Table structure for table `carbooking`
--

CREATE TABLE `carbooking` (
  `Register_ID` varchar(10) NOT NULL,
  `Car_bookingID` varchar(20) NOT NULL,
  `Start_station` varchar(10) NOT NULL,
  `Destination` varchar(20) NOT NULL,
  `Price` varchar(60) NOT NULL,
  `Time_of_Registration` int(10) NOT NULL,
  `Date_Of_Registration` date NOT NULL,
  `Date_for_Booking` date NOT NULL,
  `Adults` varchar(10) NOT NULL,
  `Children` varchar(20) NOT NULL,
  `Message` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carbooking`
--

INSERT INTO `carbooking` (`Register_ID`, `Car_bookingID`, `Start_station`, `Destination`, `Price`, `Time_of_Registration`, `Date_Of_Registration`, `Date_for_Booking`, `Adults`, `Children`, `Message`, `Status`) VALUES
('RG4000', 'TK-B11690', '', 'Palakkad', 'Rate is perkm Rs. 50', 0, '0000-00-00', '0000-00-00', '2', '1', 'ddfwerwgdfv', 'Approved'),
('RG4000', 'TK-B1690', 'Aluva', 'Palakkad', 'Rate is perkm Rs. 50', 0, '0000-00-00', '2023-06-15', '2', '1', 'gzyigm,h mncjf', 'ReqBook');

-- --------------------------------------------------------

--
-- Table structure for table `dest`
--

CREATE TABLE `dest` (
  `distance` int(11) NOT NULL,
  `destination` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dest`
--

INSERT INTO `dest` (`distance`, `destination`) VALUES
(0, 'Aluva'),
(1, 'Pulinchodu'),
(3, 'Companypady'),
(4, 'Ambattukavu'),
(5, 'Muttom'),
(7, 'Kalamassery'),
(8, 'Cochin University'),
(11, 'Edapally'),
(13, 'Palarivattom'),
(14, 'JLN junction'),
(15, 'Kaloor'),
(16, 'Lissie Jn'),
(17, 'MG road kochi'),
(18, 'Maharajas college '),
(19, 'Ernakulam south'),
(20, 'Kadavanthara'),
(21, 'Vytella'),
(22, 'Petta'),
(23, 'Tripunithura');

-- --------------------------------------------------------

--
-- Table structure for table `hotelbooking`
--

CREATE TABLE `hotelbooking` (
  `Register_ID` varchar(10) NOT NULL,
  `Hotel_BookingID` varchar(10) NOT NULL,
  `Date_OF_Booking` date NOT NULL,
  `Date_OF_Request` date NOT NULL,
  `Number_OF_Days` int(30) NOT NULL,
  `Protable_Checking_Time` varchar(30) NOT NULL,
  `Number_OF_People` int(30) NOT NULL,
  `Room_Type` varchar(50) NOT NULL,
  `Other_Reqirment` varchar(50) NOT NULL,
  `Rate_OF_Rent` int(10) NOT NULL,
  `Adults` int(5) NOT NULL,
  `Children` int(5) NOT NULL,
  `Message` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotelbooking`
--

INSERT INTO `hotelbooking` (`Register_ID`, `Hotel_BookingID`, `Date_OF_Booking`, `Date_OF_Request`, `Number_OF_Days`, `Protable_Checking_Time`, `Number_OF_People`, `Room_Type`, `Other_Reqirment`, `Rate_OF_Rent`, `Adults`, `Children`, `Message`, `Status`) VALUES
('RG4000', 'TK-B1690', '2023-06-03', '2023-06-03', 1, '09:23', 3, 'acroom', 'dgdhgjg', 500, 2, 0, 'ftsa5', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `login_id`
--

CREATE TABLE `login_id` (
  `User_Type` varchar(30) NOT NULL,
  `Register_ID` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_id`
--

INSERT INTO `login_id` (`User_Type`, `Register_ID`, `Password`) VALUES
('Admin', 'Admin', '000'),
('HotelAdmin', 'HI2001', 'hhh'),
('CarAdmin', 'CI2002', 'ccc'),
('Passenger', 'RG4000', 'tree'),
('Passenger', 'RG4001', 'www'),
('Passenger', 'RG4004', 'qwe'),
('', '', ''),
('Passenger', 'RG4000', 'tree'),
('Passenger', 'RG4000', 'tree');

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `PID` varchar(30) NOT NULL,
  `Card_id` varchar(20) NOT NULL,
  `Booking_ID` varchar(10) NOT NULL,
  `QR_Code` varchar(35) NOT NULL,
  `Start_Station` varchar(30) NOT NULL,
  `Destination` varchar(35) NOT NULL,
  `Jounery_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`PID`, `Card_id`, `Booking_ID`, `QR_Code`, `Start_Station`, `Destination`, `Jounery_date`) VALUES
('PS100', '1', 'TK-B1690', 'Generated', 'Aluva', 'JLN junction', '2023-06-15'),
('PS101', '2', 'TK-B1690', 'Generated', 'Aluva', 'JLN junction', '2023-06-15'),
('PS102', '3', 'TK-B1690', 'Generated', 'Aluva', 'JLN junction', '2023-06-15');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `Register_ID` varchar(50) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Address` varchar(60) NOT NULL,
  `Gender` varchar(11) NOT NULL,
  `Age` int(2) NOT NULL,
  `E_mail` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`Register_ID`, `Name`, `Address`, `Gender`, `Age`, `E_mail`, `Status`, `Password`) VALUES
('RG4000', 'arya', 'Treehouse', 'FeMale', 20, 'tree@gmail.com', 'Approved', 'tree');

-- --------------------------------------------------------

--
-- Table structure for table `station_fair`
--

CREATE TABLE `station_fair` (
  `Start_Station` varchar(50) NOT NULL,
  `End_Station` varchar(50) NOT NULL,
  `Distance` varchar(5) NOT NULL,
  `Ticket_fair` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticketbooking`
--

CREATE TABLE `ticketbooking` (
  `Register_ID` varchar(30) NOT NULL,
  `Booking_ID` varchar(30) NOT NULL,
  `No_of_ticket` int(30) NOT NULL,
  `Date_of_Booking` date NOT NULL,
  `Jounery_date` date NOT NULL,
  `Amount` int(20) NOT NULL,
  `Start_Station` varchar(30) NOT NULL,
  `Destination` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticketbooking`
--

INSERT INTO `ticketbooking` (`Register_ID`, `Booking_ID`, `No_of_ticket`, `Date_of_Booking`, `Jounery_date`, `Amount`, `Start_Station`, `Destination`) VALUES
('RG4000', 'TK-B1690', 3, '2023-06-03', '2023-06-15', 25, 'Aluva', 'JLN junction');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

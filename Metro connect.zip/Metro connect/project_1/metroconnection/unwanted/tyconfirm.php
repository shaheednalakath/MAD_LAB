<?php
    $rid=$_REQUEST["rId"];
	$pass=$_REQUEST["pass"];

	$conn=new mysqli("localhost","root","","metro");
    $sql="select * from login_id where Register_id='$rid' and Password='$pass'";
	$rs=$conn->query($sql);
	if($row=$rs->fetch_row())
	{
		$utyp=$row[0];
		if($utyp=="Admin")
		{
			header("Location:admin.php");
		}
		else
			if($utyp=="Passenger")
			{
				header("Location:passadmin.php");
			}
			else
				if($utyp=="CarAdmin")
				{
					header("Location:caradmin.php");
				}
				else
					if($utyp=="HotelAdmin")
					{
						header("Location:hotel admin.php");
					}
	}

?>
<?php
	$Start_Station=$_REQUEST["Start_Station"];
	$End_Station=$_REQUEST["End_Station"];
	$Distance=$_REQUEST["Distance"];
	$Ticket_fair=$_REQUEST["Ticket_fair"];
	$conn=new mysqli("localhost","root","","metro");
    $sql="insert into station_fair(Start_Station,End_Station,Distance,Ticket_fair) values('$Start_Station','$End_Station','$Distance','$Ticket_fair')";
	echo $sql;
	$conn->query($sql);
	$conn->close();
?>

<?php
	$ID=$_REQUEST["ID"];
	$Name=$_REQUEST["Name"];
	$Phno=$_REQUEST["Phno"];
	$E_mail=$_REQUEST["E_mail"];
	$Card_id=$_REQUEST["Card_id"];
	$Booking_ID=$_REQUEST["Booking_ID"];
	$QR_Code=$_REQUEST["QR_Code"];
	$conn=new mysqli("localhost","root","","metro");
    $sql="insert into passenger(ID,Name,Phno,E_mail,Card_id,Booking_ID,QR_Code) values($ID,'$Name','$Phno','$E_mail','$Card_id','$Booking_ID','$QR_Code')";
	echo $sql;
	$conn->query($sql);
	$conn->close();
?>
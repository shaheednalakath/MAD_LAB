<?php
session_start();
    $uid=$_SESSION["uid"];
	$Register_ID=$_REQUEST["Register_ID"];
	$Booking_ID=$_REQUEST["Booking_ID"];
	//$Date_OF_Booking=$_REQUEST["Date_OF_Booking"];
	$No_of_ticket=$_REQUEST["No_of_ticket"];
	//$Date_of_Booking=$_REQUEST["Date_of_Booking"];
	$Jounery_date=$_REQUEST["Jounery_date"];
	//$Amount=$_REQUEST["Amount"];
	$test = explode('|', $_POST['Start_Station']);
	$std=$test[0];
	$Start_Station=$test[1];
	$test1 = explode('|', $_POST["Destination"]);
	$dsd=$test1[0];
	$Destination=$test1[1];
	$conn=new mysqli("localhost","root","","metro");
	
	$n=0;
	try
	{
		 $sql="SELECT max(SUBSTRING(pid, 3)) from passenger ";
	$rs=$conn->query($sql);
      if($row=$rs->fetch_row())
	  {
		  $n=$row[0];
	  }
    }catch(Exception $ee)
	{
	 $n=0;	
	}
	$n=$n+100;
	echo abs($test[0]-$test1[0]);
	$dis=abs($test[0]-$test1[0]);
	if($dis<=10)
	{
		$p=20;
	}
	else
		if($dis<=15)
			$p=25;
		else
			if($dis<=20)	
				$p=30;
			else
				$p=35;
	$Amount=$p;		
	$sql="insert into ticketbooking (Register_ID,Booking_ID,No_of_ticket,Date_of_Booking,Jounery_date,Amount,Start_Station,Destination) values('$Register_ID','$Booking_ID','$No_of_ticket',current_date(),'$Jounery_date','$Amount','$Start_Station','$Destination')";
	$conn->query($sql);
	//echo $sql;		
	$pn=$n;		
	for($i=1;$i<=$No_of_ticket;$i++)
	{		
        $pid="PS".$pn;
		$cardid=$i;
		$QR_Code='Generated';
		$sql="insert into passenger(PID,Card_id,Booking_ID,QR_Code,Jounery_date,Start_Station,Destination) values('$pid','$cardid','$Booking_ID','$QR_Code','$Jounery_date','$Start_Station','$Destination')";
	    //echo $sql;
		$pn++;
		$conn->query($sql);
	}
	//$conn->query($sql);
	$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home</title>
		<meta charset="utf-8">
		<meta name = "format-detection" content = "telephone=no" />
		<link rel="icon" href="images/favicon.ico">
		<link rel="shortcut icon" href="images/favicon.ico" />
		<link rel="stylesheet" href="booking/css/booking.css">
		<link rel="stylesheet" href="css/camera.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/style.css">
		<script src="js/jquery.js"></script>
		<script src="js/jquery-migrate-1.2.1.js"></script>
		<script src="js/script.js"></script>
		<script src="js/superfish.js"></script>
		<script src="js/jquery.ui.totop.js"></script>
		<script src="js/jquery.equalheights.js"></script>
		<script src="js/jquery.mobilemenu.js"></script>
		<script src="js/jquery.easing.1.3.js"></script>
		<script src="js/owl.carousel.js"></script>
		<script src="js/camera.js"></script>
		<!--[if (gt IE 9)|!(IE)]><!-->
		<script src="js/jquery.mobile.customized.min.js"></script>
		<!--<![endif]-->
		<script src="booking/js/booking.js"></script>
		<script>
			$(document).ready(function(){
				jQuery('#camera_wrap').camera({
					loader: false,
					pagination: false ,
					minHeight: '444',
					thumbnails: false,
					height: '28.28125%',
					caption: true,
					navigation: true,
					fx: 'mosaic'
				});
				$().UItoTop({ easingType: 'easeOutQuart' });
			});
		</script>

		<style>
table, th, td {
  border: 3px solid;
}
</style>
	</head>
	<body class="page1" id="top">
		<div class="main">
<!--==============================header=================================-->
			<header>
				<div class="menu_block ">
					<div class="container_12">
						<div class="grid_12">
							<nav class="horizontal-nav full-width horizontalNav-notprocessed">
								<ul class="sf-menu">
								    <li class="current"><a href="indexx.phpa">Home</a></li>
									<li><a href="Ticketbook.php">Bookticket</a></li>
									<li><a href="hbook.php">Hotel book</a></li>
									<li><a href="carbook.php">car book</a></li>
									<li><a href="ticketcancellation.php">tkcancellation</a></li>
								</ul>
							</nav>
							<div class="clear"></div>
						</div>
						<div class="clear"></div>
					</div>
				</div>

				<div class="clear"></div>
			</header>


			<div class="c_phone">
				<div class="container_12">
					<div class="grid_12">
						<div></div>
						<span>Passenger List </span>
					</div>
					<div class="clear"></div>
					<div class="clear"></div>
					<div class="clear"></div>
				</div>
			</div>
<!--==============================Content=================================-->
			<div class="content"><div class="ic"> </div>
				<div class="container_12">
					<div class="grid_5">
					<div class="clear"></div>
					<div class="clear"></div>
					<h4>For Booking Id <?php echo $Booking_ID; ?></h4>
					<div class="clear"></div>
					<div class="clear"></div>
					    <table align="center" height="150" width="1000" border="5px">
					 <tr>

					 <th>Card Numbers</th>
					 <th>Passenger ID</th>
					<th>Start_Station</th>
					 <th>Destination</th>
					 <th>Jounery_date</th>
					 <th>QR_Code</th>
					 
			         </tr>
					 <?php
						for($i=1;$i<=$No_of_ticket;$i++)
						{
							$pid="PS".$n;
							$cardid=$i;
							$QR_Code='Generated';
							

					 ?>
					    <tr>
						<th> <?php echo $cardid; ?></th>
						<th> <?php echo $pid; ?></th>
						<th> <?php echo $Start_Station; ?></th>
						<th> <?php echo $Destination; ?></th>
						<th> <?php echo $Jounery_date; ?></th>
						<th> <img src="QR_code/qr<?php echo $i; ?>.jpg" width="60" height="60"> </th>
						
						</tr>
						<?php
						$n++;
						}
						?>
						
					 </table>
					</div>
					
					<div class="clear"></div>
				</div>
			</div>
		</div>
<!--==============================footer=================================-->
		<footer>
			<div class="container_12">
				<div class="grid_12">
					<div class="f_phone"><span>Call Us:</span> + 1800 425 0355</div>
					<div class="socials">
						<a href="#" class="fa fa-twitter"></a>
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-google-plus"></a>
					</div>
					<div class="copy">
						<div class="st1">
						<div class="brand">Metro<span class="color1">C</span>onnect</div>
						&copy; 2023| <a href="#">Privacy Policy</a> </div> Website designed by <a href="http://www.templatemonster.com/" rel="nofollow">carmel college</a>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</footer>
		<script>
			$(function (){
				$('#bookingForm').bookingForm({
					ownerEmail: '#'
				});
			})
			$(function() {
				$('#bookingForm input, #bookingForm textarea').placeholder();
			});
		</script>
	</body>
</html>

<?php
	$conn=new mysqli("localhost","root","","metro");
    $sql="select * from carbooking  where status='ReqBook'";
	$rs=$conn->query($sql);
	

?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Home</title>
		<meta charset="utf-8">
		<meta name = "format-detection" content = "telephone=no" />
		<link rel="icon" href="images/favicon.ico">
		<link rel="shortcut icon" href="images/favicon.ico" />
		<link rel="stylesheet" href="booking/css/booking.css">
		<link rel="stylesheet" href="css/camera.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/style.css">
		<script src="js/jquery.js"></script>
		<script src="js/jquery-migrate-1.2.1.js"></script>
		<script src="js/script.js"></script>
		<script src="js/superfish.js"></script>
		<script src="js/jquery.ui.totop.js"></script>
		<script src="js/jquery.equalheights.js"></script>
		<script src="js/jquery.mobilemenu.js"></script>
		<script src="js/jquery.easing.1.3.js"></script>
		<script src="js/owl.carousel.js"></script>
		<script src="js/camera.js"></script>
		<!--[if (gt IE 9)|!(IE)]><!-->
		<script src="js/jquery.mobile.customized.min.js"></script>
		<!--<![endif]-->
		<script src="booking/js/booking.js"></script>
		<script>
			$(document).ready(function(){
				jQuery('#camera_wrap').camera({
					loader: false,
					pagination: false ,
					minHeight: '444',
					thumbnails: false,
					height: '28.28125%',
					caption: true,
					navigation: true,
					fx: 'mosaic'
				});
				$().UItoTop({ easingType: 'easeOutQuart' });
			});
		</script>
		<!--[if lt IE 8]>
			<div style=' clear: both; text-align:center; position: relative;'>
				<a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
					<img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
				</a>
			</div>
			<![endif]-->
		<!--[if lt IE 9]>
			<script src="js/html5shiv.js"></script>
			<link rel="stylesheet" media="screen" href="css/ie.css">
		<![endif]-->
		<style>
table, th, td {
  border: 3px solid;
}
</style>
	</head>
	<body class="page1" id="top">
		<div class="main">
<!--==============================header=================================-->
			<header>
				<div class="menu_block ">
					<div class="container_12">
						<div class="grid_12">
							<nav class="horizontal-nav full-width horizontalNav-notprocessed">
								<ul class="sf-menu">
									<li class="current"><a href="indexx.php">Home</a></li>
									<li><a href="carbooktable1.php">Carbooking List</a></li>
									<li><a href="cartable.php">Approve booking</a></li>
									<li><a href="logout.php">Logout</a></li>
								</ul>
							</nav>
							<div class="clear"></div>
						</div>
						<div class="clear"></div>
					</div>
				</div>

				<div class="clear"></div>
			</header>


			<div class="c_phone">
				<div class="container_12">
					<div class="grid_12">
						<div></div
						<span>Carbooking List</span>
					</div>
					<div class="clear"></div>
				</div>
			</div>
<!--==============================Content=================================-->
		<div class="content"><div class="ic"> </div>
				<div class="container_12">
					<div class="grid_5">
						<table align="center" height="150" width="1000" border="5px">
					 <tr>
					 <th>Register ID</th>
					 <th>Car bookingID</th>
					 <th>Start_station</th>
                     <th>Destination</th>					 
					 <th>Price</th>
					 <th>Date_for_Booking</th>
					 <th>Adults</th>
					 <th>Children</th>
					 <th>Message</th>					 
					 </tr>
					 <?php
						while($row=$rs->fetch_row())
						{
							$regid=$row[0];
							$Car_bookingID=$row[1];
							$Start_station=$row[2];
                            $Destination=$row[3];							
							$Price	=$row[4];
                            $Date_for_Booking=$row[7];							
							$Adults=$row[8];
							$Children=$row[9];
							$Message=$row[10];							
							
					 ?>
					 <tr>
						<th> <?php echo $regid; ?></th>
						<th> <?php echo $Car_bookingID; ?> </th>
						<th> <?php echo $Start_station; ?> </th>
						<th> <?php echo $Destination; ?> </th>
						<th> <?php echo $Price; ?> </th>
						<th> <?php echo $Date_for_Booking; ?></th>
						<th> <?php echo $Adults; ?> </th>
						<th> <?php echo $Children; ?> </th>
						<th> <?php echo $Message; ?> </th>

					</tr>
						<?php
						}
						?>
						
					 </table>

					</div>
				
					<div class="clear"></div>
				</div>
			</div>
		</div>
<!--==============================footer=================================-->
		<footer>
			<div class="container_12">
				<div class="grid_12">
					<div class="f_phone"><span>Call Us:</span> + 1800 425 0355</div>
					<div class="socials">
						<a href="#" class="fa fa-twitter"></a>
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-google-plus"></a>
					</div>
					<div class="copy">
						<div class="st1">
						<div class="brand">Metro<span class="color1">C</span>onnect</div>
						&copy; 2023| <a href="#">Privacy Policy</a> </div> Website designed by <a href="http://www.templatemonster.com/" rel="nofollow">carmel college</a>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</footer>
		<script>
			$(function (){
				$('#bookingForm').bookingForm({
					ownerEmail: '#'
				});
			})
			$(function() {
				$('#bookingForm input, #bookingForm textarea').placeholder();
			});
		</script>
	</body>
</html>
<?php

	$Register_id1=$_REQUEST["id"];

	$Status1="Approved";
	$password1=$_REQUEST["pass"];
	$conn=new mysqli("localhost","root","","metro");
    $sql="insert into carbooking(Register_ID,Car_bookingID,Start_station,Destination,Price,Time_of_Registration,Date_Of_Registration,Date_for_Booking,Adults,Children,Message,Status) values('$Register_ID1','$Car_bookingID','$Start_station','$Destination','$Price','$Time_of_Registration','$Date_Of_Registration','$Date_for_Booking','$Adults','$Children','$Message','$Status')";
	echo $sql;
	$conn->query($sql);
	$sql="update registration set status='$Status1' where Register_ID='$Register_ID1'";
	$conn->query($sql);
	$conn->close();

?>